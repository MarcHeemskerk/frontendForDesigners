var btn = document.querySelectorAll("button");
var x = document.querySelectorAll(".mySlides");

console.log(btn);

var slideIndex = 1;

function showDivs(n) {

  if (n > x.length){
      slideIndex = 1;
  }

  else if (n < 1) {
      slideIndex = x.length;
  }

  var i;
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }

  x[slideIndex-1].style.display = "block";
}

showDivs(slideIndex);

function plusDivs(n) {
  console.log("yeet");
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

btn[0].addEventListener("click", plusDivs(0));
btn[1].addEventListener("click", plusDivs(1));

































/*

var currentImg = 1;
var allImgs = document.querySelectorAll(".mySlides");
var btnLeft = document.getElementById("buttonLeft");
var btnRight = document.getElementById("buttonRight");

function showImg(nummer) {

console.log(nummer);
    if (nummer > allImgs.length) {
        currentImg = 1;
    }

    else if (nummer < 1) {
        currentImg = allImgs.length;
    }

    var i;
    for (i = 0; i < allImgs.length; i++) {
        allImgs[i].style.display = "none";
    }

    allImgs[currentImg -1].style.display = "block";
}

function plusOfMin(nummer) {
    console.log(nummer);
    showImg(currentImg += nummer);
}

showImg(currentImg);

btnLeft.addEventListener("click", plusOfMin,(-1));
btnRight.addEventListener("click", plusOfMin,(1));

console.log(allImgs);

*/
