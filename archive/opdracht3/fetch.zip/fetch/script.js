//cd documents
//python -m SimpleHTTPServer 8090
//ctrl + ç voor uitschakelen

var header = document.querySelector('header');
var section = document.querySelector('section');
//var requestURL = 'https://api.sunrise-sunset.org/json?';
var lat;
var lng;
var requestURL;

var today = new Date();

var tommorow = new Date();
tommorow.setDate(tommorow.getDate() + 1);

var month = today.getMonth();
if (month == 0) {
    month = "Jan";
} else if (month == 1) {
    month = "Feb";
} else if (month == 2) {
    month = "Mar";
} else if (month == 3) {
    month = "Apr";
} else if (month == 4) {
    month = "May";
} else if (month == 5) {
    month = "Jun";
} else if (month == 6) {
    month = "Jul";
} else if (month == 7) {
    month = "Aug";
} else if (month == 8) {
    month = "Sep";
} else if (month == 9) {
    month = "Oct";
} else if (month == 10) {
    month = "Nov";
} else if (month == 11) {
    month = "Dec";
}

var dateOfTommorrow = tommorow.getDate();
var n = dateOfTommorrow.toString();
var getFullYear = tommorow.getFullYear();
var u = getFullYear.toString();


//var seconds = today.getSeconds();
//if (seconds < 10) {
//    seconds = "0" + seconds;
//}
//var minutes = today.getMinutes();
//if (minutes < 10) {
//    minutes = "0" + minutes;
//}

var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();

//var time = (today.getHours() % 12) + ":" + minutes + ":" + seconds;

header.addEventListener("click", function () {
    navigator.geolocation.getCurrentPosition(function (position) {
        lat = position.coords.latitude;
        lng = position.coords.longitude;
        //console.log("FUNCTION getCurrentPosition");
        //console.log("latitude", lat);
        //console.log("longitude", lng);
        //console.log(date);

        requestURL = `https://api.sunrise-sunset.org/json?lat=${lat}&lng=${lng}&date=${date}`;

        requestHandler(requestURL);
    });
});



function requestHandler(value) {

    var request = new XMLHttpRequest();
    request.open('GET', value);
    request.responseType = 'json';
    request.send();
    request.onload = function () {

        //console.log("FUNCTION request.onload");
        //console.log(request.response);
        showTime(request.response);
    };


    //deze functie kan je html elementen aanmaken.
    function showTime(jsonObj) {
        //console.log("FUNCTION: showTime");

        var data = jsonObj;
        //console.log(data);

        var sunriseData = data.results.sunrise;
        var sunsetData = data.results.sunset;


        // : weg halen bij sunset
        var inputsunriseData = sunriseData;
        var outputsunsriseData = inputsunriseData.replace(/ \D+/g, '');

        var inputsunsetData = sunsetData;
        var outputsunsetData = inputsunsetData.replace(/ \D+/g, '');


        //console.log(outputsunsriseData);



        // Time calculations for days, hours, minutes and seconds



    var remaining = document.createElement('h2');



        var article = document.createElement('article');
        var sunrise = document.createElement('p');
        var sunset = document.createElement('p');

        sunrise.textContent = 'Sunrise in: ' + outputsunsriseData + "AM";
        sunset.textContent = 'Sunset In ' + outputsunsetData + "PM";

        article.appendChild(sunrise);
        article.appendChild(sunset);
        section.appendChild(article);
            article.appendChild(remaining);
        //setTimeout(RemainingTime(outputsunsriseData, outputsunsetData), 1 s);

        setInterval(function () {
            RemainingTime(outputsunsetData, outputsunsriseData)
        }, 1000);

    }
    /*
                // : weg halen bij sunrise
                var inputsunriseData = sunriseData;
                var cleantxt = inputsunriseData.replace(/\:/g, "");
                var outputsunsriseData = cleantxt.replace(/ \D+/g, '');
                console.log(outputsunsriseData);

                // : weg halen bij sunset
                var inputsunsetData = sunsetData;
                var cleantxt = inputsunsetData.replace(/\:/g, "");
                var outputsunsetData = cleantxt.replace(/ \D+/g, '');
                console.log(outputsunsetData);

                // : weg halen bij huidige tijd
                var inputTime = time;
                var cleantxt = inputTime.replace(/\:/g, "");
                var outputTime = cleantxt.replace(/ \D+/g, '');
                console.log(outputTime);


                outputsunsriseData = parseInt(outputsunsriseData);
                outputsunsetData = parseInt(outputsunsetData);
                outputTime = parseInt(outputTime);


                var remainingTime = outputsunsetData - outputTime;

                if (remainingTime < 0) {
                    if (outputsunsriseData < outputTime) {
                        var int = 120000 - outputTime;
                        var int = int + outputsunsriseData;
                        remainingTime = int;

                    } else if (outputsunsriseData > outputTime) {
                        var int = outputsunsriseData - outputTime;
                        remainingTime = int;
                    }
                }


        console.log(outputsunsetData);
        console.log(outputTime);
*/
}

function RemainingTime(valueSunset, valueSunrise) {

    /*
            //        console.log(month);
            //        console.log(tommorow.getDate());
            //        console.log(tommorow.getFullYear());
            //        console.log(outputsunsriseData);

            //console.log(month + " " + tommorow.getDate() + ", " + tommorow.getFullYear() + " " + outputsunsriseData);
    */
    /*
     //var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();
     // Update the count down every 1 second
     //console.log(countDownDate);

     //console.log(tommorow.getMonth());
     // Get todays date and time
     */

    var countDownDate = new Date(month + " " + n + ", " + u + " " + valueSunset).getTime();

    var now = new Date().getTime();

    var distance = countDownDate - now;

    //var d = Math.floor(distance / (1000 * 60 * 60 * 24));
    var h = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var m = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var s = Math.floor((distance % (1000 * 60)) / 1000);



    var remaining = document.createElement('h2');

    remaining.innerHTML = 'Remaining Time: ' + (h - 12) + "hours " + m + "minutes " + s + "seconds ";




}
