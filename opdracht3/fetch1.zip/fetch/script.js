//cd documents
//python -m SimpleHTTPServer 8090
//ctrl + ç voor uitschakelen

var header = document.querySelector('header');
var section = document.querySelector('section');
//var requestURL = 'https://api.sunrise-sunset.org/json?';
var lat;
var lng;
var requestURL;
var year = "2019";
var month = "03";
var day = "28";
var fullDate = year + "-" + month + "-" + day;
var remainingTimeData;



header.addEventListener("click", function () {
    navigator.geolocation.getCurrentPosition(function (position) {
        lat = position.coords.latitude;
        lng = position.coords.longitude;
        console.log("FUNCTION getCurrentPosition");
        console.log("latitude", lat);
        console.log("longitude", lng);
        console.log(fullDate);


        requestURL = `https://api.sunrise-sunset.org/json?lat=${lat}&lng=${lng}&date=${fullDate}`;

        requestHandler(requestURL);
    });
});


function requestHandler(value) {

    var request = new XMLHttpRequest();
    request.open('GET', value);
    request.responseType = 'json';
    request.send();
    request.onload = function () {

        console.log("FUNCTION request.onload");
        console.log(request.response);
        showTime(request.response);
    };


    //deze functie kan je html elementen aanmaken.
    function showTime(jsonObj) {
        console.log("FUNCTION: showTime");

        var data = jsonObj;
        console.log(data);


        var sunriseData = data.results.sunrise;
        var remainingTimeData = "00:01:45"
        var sunsetData = data.results.sunset;

        var article = document.createElement('article');
        var sunrise = document.createElement('p');
        var remaining = document.createElement('h2');
        var sunset = document.createElement('p');


        sunrise.textContent = 'Sunrise in: ' + sunriseData;

        remaining.textContent = 'Remaining Time: ' + remainingTimeData;

        sunset.textContent = 'Sunset In ' + sunsetData;

        article.appendChild(sunrise);
        article.appendChild(remaining);
        article.appendChild(sunset);
        section.appendChild(article);
        console.log(sunsetData);

    }
}

